// ==UserScript==
// @name         Jayden's mod menu (Max Farms & Garden - No Give Seeds)
// @namespace    https://orteil.dashnet.org/cookieclicker/
// @version      4.3
// @description  Cookie Clicker mod menu: Max out Farms & Garden with one button (replaces Give All Garden Seeds). Hotkey: "/" to show/hide menu. Funny features, danger features, building amount/level setters, unlock all upgrades/achievements, instant cookies/lumps, and more!
// @author       Susk3y-Slay3r123 & DarkDeath & Copilot & Jayden
// @match        https://orteil.dashnet.org/cookieclicker/*
// @grant        none
// @run-at       document-idle
// @license MIT
// ==/UserScript==

(function() {
    function waitForGame(cb) {
        if (typeof Game !== 'undefined' && Game.ready && Game.UpgradesById && Game.ObjectsById) return cb();
        setTimeout(() => waitForGame(cb), 300);
    }

    waitForGame(initMenu);

    function initMenu() {
        let autoClickerOn = false, autoClickerInterval = null;
        let menuVisible = true;
        let dogeTextActive = false;
        let dogeTextTimers = [];

        // Insert styles
        const style = document.createElement('style');
        style.textContent = `
            #cookie-clicker-menu {
                position: fixed;
                top: 10px;
                right: 10px;
                background-color: rgba(0, 0, 0, 0.92);
                color: white;
                border: 1.5px solid #00FFCC;
                padding: 0;
                z-index: 1000000;
                font-family: Arial, sans-serif;
                width: 280px;
                border-radius: 12px;
                box-shadow: 0 0 16px #000a;
                display: block;
            }
            #cookie-clicker-menu .menu-title {
                margin: 0;
                padding: 7px 10px;
                cursor: move;
                user-select: none;
                border-bottom: 1px solid #FFD700;
                background: #222;
                font-size: 15px;
                border-radius: 12px 12px 0 0;
                display: flex;
                justify-content: space-between;
                align-items: center;
                min-height: 32px;
            }
            #cookie-clicker-menu .menu-content {
                padding: 9px;
                display: block;
                max-height: 95vh;
                height: auto;
                overflow-y: auto;
            }
            #cookie-clicker-menu label, #cookie-clicker-menu input {
                vertical-align: middle;
                font-size: 13px;
            }
            #cookie-clicker-menu button {
                display: block;
                width: 100%;
                margin-bottom: 7px;
                padding: 5px;
                background-color: #007bff;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                transition: background-color 0.3s;
                font-size: 13px;
            }
            #cookie-clicker-menu button:hover {
                background-color: #0056b3;
            }
            #cookie-clicker-menu .danger-btn {
                background-color: #dc3545 !important;
            }
            #cookie-clicker-menu .danger-btn:hover {
                background-color: #c82333 !important;
            }
            #cookie-clicker-menu .danger-btn2 {
                background-color: #a900e3 !important;
                color: #fff !important;
            }
            #cookie-clicker-menu .danger-btn2:hover {
                background-color: #7900ac !important;
            }
            #cookie-clicker-menu .close-btn {
                background: #333;
                color: #FFD700;
            }
            #cookie-clicker-menu .section-title {
                color: #FFD700;
                margin-top: 8px;
                margin-bottom: 2px;
                font-weight: bold;
                font-size: 13px;
            }
            #cookie-clicker-menu input[type='number'] {
                width: 75px;
                padding: 2px 4px;
                background: #444;
                color: #fff;
                border: 1px solid #333;
                border-radius: 4px;
                margin-right: 5px;
                font-size: 13px;
            }
            .custom-window {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background-color: rgba(0,0,0,0.97);
                color: white;
                border: 2px solid #FFD700;
                padding: 15px;
                z-index: 1000001;
                font-family: Arial, sans-serif;
                width: 250px;
                text-align: center;
                border-radius: 14px;
                box-shadow: 0 0 20px #000c;
            }
            .custom-window input, .custom-window textarea {
                width: 92%;
                padding: 5px;
                margin: 6px 0;
                box-sizing: border-box;
                background: #333;
                color: #FFD700;
                border-radius: 6px;
                border: 1px solid #FFD700;
                font-size: 14px;
            }
            .custom-window textarea {
                resize: vertical;
                min-height: 48px;
                max-height: 120px;
            }
            .custom-window button {
                margin: 6px;
                padding: 6px 12px;
                background-color: #FFD700;
                color: #222;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-weight: bold;
                font-size: 13px;
            }
            .custom-window button:hover {
                background-color: #ffe666;
            }
            .custom-window h4 {
                margin-bottom: 6px;
                font-size: 15px;
            }
            /* Funny Features */
            .bigcookie-spin {
                animation: bigcookie-spin 2s linear;
            }
            @keyframes bigcookie-spin {
                0% { transform: rotate(0deg) scale(1);}
                80% { transform: rotate(2880deg) scale(1.3);}
                100% { transform: rotate(3600deg) scale(1);}
            }
            .funny-golden-cookie {
                position: fixed !important;
                z-index: 999999 !important;
                width: 48px !important;
                height: 48px !important;
                pointer-events: none;
                animation: parade-move 4s linear forwards;
            }
            @keyframes parade-move {
                0% { left: -60px; }
                100% { left: 100vw;}
            }
            .doge-float {
                position: fixed;
                z-index: 999999;
                font-family: Comic Sans MS, Comic Sans, cursive;
                font-weight: bold;
                font-size: 2em;
                pointer-events:none;
                user-select:none;
                text-shadow: 2px 2px 8px #000, 0 0 4px #FFD700;
                animation: doge-float-move 2.5s linear forwards;
            }
            @keyframes doge-float-move {
                0% { opacity: 0; transform: translateY(40px) scale(0.7);}
                20% {opacity:1;}
                90% {opacity:1;}
                100% { opacity: 0; transform: translateY(-80px) scale(1);}
            }
            .nyancat-container {
                position: fixed;
                left: -120px;
                bottom: 80px;
                z-index: 1000001;
                pointer-events: none;
                animation: nyan-move 8s linear forwards;
            }
            @keyframes nyan-move {
                from { left: -120px;}
                to { left: 120vw;}
            }
            .nyan-rainbow {
                position: absolute;
                left: 0;
                top: 30px;
                width: 320px;
                height: 24px;
                background: repeating-linear-gradient(
                    to right,
                    #FF0018 0 16px,
                    #FFA52C 16px 32px,
                    #FFD700 32px 48px,
                    #008018 48px 64px,
                    #0000F9 64px 80px,
                    #86007D 80px 96px
                );
                filter: blur(1.2px);
                border-radius: 8px;
                opacity: 0.7;
            }
        `;
        document.head.appendChild(style);

        // Build menu HTML
        const menu = document.createElement('div');
        menu.id = 'cookie-clicker-menu';
        menu.innerHTML = `
            <div class="menu-title">
                <span>🍪 Jayden's Mod Menu</span>
            </div>
            <div class="menu-content">
                <div class="section-title">Building Editors</div>
                <label for="cc-product-level-input">Set Product Level (All):</label>
                <input type="number" min="0" max="999" value="0" id="cc-product-level-input" style="width:75px;">
                <button id="cc-set-product-level-btn" type="button">Set Product Level</button>
                <label for="cc-building-amount-input">Set Building Amount (All except Cursor):</label>
                <input type="number" min="0" max="999999" value="0" id="cc-building-amount-input" style="width:75px;">
                <button id="cc-set-building-amount-btn" type="button">Set Building Amount</button>
                <div class="section-title">Funny Features</div>
                <button id="cc-bigcookie-spin-btn" type="button">Big Cookie Spins</button>
                <button id="cc-golden-parade-btn" type="button">Golden Cookie Parade</button>
                <button id="cc-doge-mode-btn" type="button">Doge Mode</button>
                <button id="cc-nyancat-btn" type="button">Nyan Cat Mode</button>
                <div class="section-title">Cookies & Lumps</div>
                <label>Add cookies:</label>
                <input type="number" id="cc-add-cookies" placeholder="Amount">
                <button id="cc-add-cookies-btn" type="button">Add Cookies</button>
                <label>Add sugar lumps:</label>
                <input type="number" id="cc-add-lumps" placeholder="Amount">
                <button id="cc-add-lumps-btn" type="button">Add Lumps</button>
                <button id="cc-remove-cookies-btn" type="button">Remove All Cookies</button>
                <div class="section-title">Auto Clicker</div>
                <button id="cc-auto-clicker-btn" type="button">Start Auto-Clicker</button>
                <div class="section-title">Upgrades & Achievements</div>
                <button id="cc-unlock-upgrades-btn" type="button">Unlock All Upgrades</button>
                <button id="cc-unlock-achievements-btn" type="button">Unlock All Achievements</button>
                <div class="section-title">Garden</div>
                <button id="cc-max-farms-garden-btn" type="button" style="background:#FFD700;color:#222;">Max Out Farms & Garden</button>
                <div class="section-title">Game Speed</div>
                <label for="cc-fps-input">FPS:</label>
                <input type="number" min="1" max="999999" value="30" id="cc-fps-input" style="width:75px;">
                <button id="cc-set-fps-btn" type="button">Set FPS</button>
                <span style="font-size:12px;">Current FPS: <span id="cc-fps-value">30</span></span>
                <div class="section-title">Custom Notification</div>
                <button id="cc-custom-notification-btn" type="button">Show Custom Notification</button>
                <div class="section-title">Danger Zone</div>
                <button class="danger-btn" id="cc-ruin-btn" type="button">Ruin the Fun</button>
                <button class="danger-btn2" id="cc-break-game-btn" type="button">Break Game (999... Cursors)</button>
                <button class="close-btn" id="cc-close-btn" type="button">Close Menu</button>
                <div style="font-size:11px;color:#FFD700;margin-top:8px;">Press "/" to toggle this menu!</div>
            </div>
        `;
        document.body.appendChild(menu);

        // Draggable menu
        let isDragging = false, currentX, currentY, initialX, initialY, xOffset = 0, yOffset = 0;
        menu.querySelector('.menu-title').addEventListener('mousedown', dragStart);
        document.addEventListener('mousemove', drag);
        document.addEventListener('mouseup', dragEnd);

        function dragStart(e) {
            initialX = e.clientX - xOffset;
            initialY = e.clientY - yOffset;
            isDragging = true;
        }
        function drag(e) {
            if (isDragging) {
                e.preventDefault();
                currentX = e.clientX - initialX;
                currentY = e.clientY - initialY;
                xOffset = currentX;
                yOffset = currentY;
                setTranslate(currentX, currentY, menu);
            }
        }
        function dragEnd(e) {
            initialX = currentX;
            initialY = currentY;
            isDragging = false;
        }
        function setTranslate(xPos, yPos, el) {
            el.style.transform = `translate3d(${xPos}px, ${yPos}px, 0)`;
        }

        // Toggling menu with "/" key
        document.addEventListener('keydown', function(e) {
            if (e.key === '/' && !e.repeat && !e.ctrlKey && !e.altKey && !e.metaKey) {
                if (document.activeElement && (
                    document.activeElement.tagName === "INPUT" ||
                    document.activeElement.tagName === "TEXTAREA" ||
                    document.activeElement.isContentEditable
                )) return;
                menuVisible = !menuVisible;
                menu.style.display = menuVisible ? "block" : "none";
            }
        });

        // UI helpers
        function createAlertWindow(message, title="Message") {
            const alertWindow = document.createElement('div');
            alertWindow.className = 'custom-window';
            alertWindow.innerHTML = `
                <h4>${title}</h4>
                <p>${message}</p>
                <button class="ok">OK</button>
            `;
            document.body.appendChild(alertWindow);
            alertWindow.querySelector('.ok').addEventListener('click', () => {
                document.body.removeChild(alertWindow);
            });
        }
        function customNotificationPopup() {
            const popup = document.createElement('div');
            popup.className = 'custom-window';
            popup.innerHTML = `
                <h4>Custom Notification</h4>
                <input id="cc-custom-notification-title" placeholder="Notification Title" maxlength="50" />
                <textarea id="cc-custom-notification-body" placeholder="Notification Text" rows="3" maxlength="140"></textarea>
                <button id="cc-custom-notification-send">Show Notification</button>
                <button id="cc-custom-notification-cancel">Cancel</button>
            `;
            document.body.appendChild(popup);
            popup.querySelector('#cc-custom-notification-send').addEventListener('click', () => {
                const title = popup.querySelector('#cc-custom-notification-title').value.trim() || 'Custom Notification';
                const body = popup.querySelector('#cc-custom-notification-body').value.trim() || '';
                showCustomNotification(title, body);
                document.body.removeChild(popup);
            });
            popup.querySelector('#cc-custom-notification-cancel').addEventListener('click', () => {
                document.body.removeChild(popup);
            });
        }
        function showCustomNotification(title, body) {
            if (typeof Game !== "undefined" && typeof Game.Notify === "function") {
                Game.Notify(title, body, [16,5]);
            } else {
                createAlertWindow(body, title);
            }
        }

        // Building Editors
        const productLevelInput = document.getElementById('cc-product-level-input');
        const setProductLevelBtn = document.getElementById('cc-set-product-level-btn');
        function setProductLevelForAll(val) {
            val = parseInt(val);
            if (isNaN(val) || val < 0) {
                createAlertWindow("Enter a valid non-negative number.");
                return;
            }
            let count = 0;
            Object.values(Game.ObjectsById).forEach(obj => {
                if (typeof obj.level !== "undefined") {
                    obj.level = val;
                    count++;
                }
            });
            createAlertWindow(`Set product level for ${count} buildings to ${val}.`);
        }
        setProductLevelBtn.onclick = function() {
            setProductLevelForAll(productLevelInput.value);
        };
        productLevelInput.onkeydown = function(e) {
            if (e.key === 'Enter') setProductLevelForAll(productLevelInput.value);
        };

        const buildingAmountInput = document.getElementById('cc-building-amount-input');
        const setBuildingAmountBtn = document.getElementById('cc-set-building-amount-btn');
        function setAllBuildingsAmount(val) {
            val = parseInt(val);
            if (isNaN(val) || val < 0) {
                createAlertWindow("Enter a valid non-negative number.");
                return;
            }
            let count = 0;
            Object.values(Game.ObjectsById).forEach(obj => {
                if (obj.name.toLowerCase() !== "cursor") {
                    obj.amount = val;
                    count++;
                }
            });
            createAlertWindow(`Set amount for ${count} buildings (except Cursor) to ${val}.`);
        }
        setBuildingAmountBtn.onclick = function() {
            setAllBuildingsAmount(buildingAmountInput.value);
        };
        buildingAmountInput.onkeydown = function(e) {
            if (e.key === 'Enter') setAllBuildingsAmount(buildingAmountInput.value);
        };

        // Funny Feature 9: Big Cookie Spins
        function bigCookieSpin() {
            const cookie = document.getElementById('bigCookie');
            if (!cookie) return;
            cookie.classList.add('bigcookie-spin');
            setTimeout(() => {
                cookie.classList.remove('bigcookie-spin');
            }, 2000);
        }

        // Funny Feature 10: Golden Cookie Parade
        function goldenCookieParade() {
            for (let i = 0; i < 9; ++i) {
                setTimeout(() => {
                    let img = document.createElement('img');
                    img.src = Game.res && Game.res['img/goldCookie.png'] ? Game.res['img/goldCookie.png'].src : 'https://orteil.dashnet.org/cookieclicker/img/goldCookie.png';
                    img.className = 'funny-golden-cookie';
                    img.style.top = (60 + i * 38) + 'px';
                    img.style.left = '-60px';
                    document.body.appendChild(img);
                    setTimeout(() => {if(img.parentNode) document.body.removeChild(img);}, 4000);
                }, i * 320);
            }
        }

        // Funny Feature 11: Doge Mode
        function dogeMode() {
            if (dogeTextActive) {
                dogeTextActive = false;
                dogeTextTimers.forEach(clearTimeout);
                dogeTextTimers = [];
                Array.from(document.querySelectorAll('.doge-float')).forEach(e=>e.remove());
                createAlertWindow("Doge Mode OFF. Wow!","Doge Mode");
                return;
            }
            dogeTextActive = true;
            createAlertWindow("Doge Mode ON. Such fun!","Doge Mode");
            const dogeWords = [
                "wow", "such cookie", "very click", "so upgrade", "much golden", "many lumps", "so sugar",
                "very mod", "such cheat", "much fun", "very fast", "so spin", "much wow", "such game", "so bake"
            ];
            function randomColor() {
                const colors = ["#ff69b4","#ffb347","#b4ff69","#69fff5","#fff569","#b469ff","#69b4ff","#00FFCC"];
                return colors[Math.floor(Math.random()*colors.length)];
            }
            function spawnDogeText() {
                if (!dogeTextActive) return;
                let div = document.createElement('div');
                div.className = 'doge-float';
                div.textContent = dogeWords[Math.floor(Math.random()*dogeWords.length)];
                div.style.left = (Math.random()*80+10)+'vw';
                div.style.top = (Math.random()*60+20)+'vh';
                div.style.color = randomColor();
                document.body.appendChild(div);
                setTimeout(()=>{div.remove();}, 2500);
                if (dogeTextActive) {
                    let t = setTimeout(spawnDogeText, Math.random()*480+280);
                    dogeTextTimers.push(t);
                }
            }
            spawnDogeText();
        }

        // Funny Feature 13: Nyan Cat Mode
        function nyanCatMode() {
            if (document.querySelector('.nyancat-container')) return;
            let container = document.createElement('div');
            container.className = 'nyancat-container';
            let rainbow = document.createElement('div');
            rainbow.className = 'nyan-rainbow';
            container.appendChild(rainbow);
            let img = document.createElement('img');
            img.src = 'https://media.giphy.com/media/sIIhZliB2McAo/giphy.gif';
            img.style.width = '120px';
            img.style.height = '72px';
            img.style.position = 'relative';
            img.style.left = '0';
            img.style.top = '-8px';
            container.appendChild(img);
            document.body.appendChild(container);
            setTimeout(()=>{container.remove();},8000);
        }

        // Max Out Farms & Garden Feature
        function maxOutFarmsGarden() {
            let farm = Game.Objects['Farm'];
            if (!farm) {
                createAlertWindow('You do not have Farms unlocked yet!', 'Max Farms & Garden');
                return;
            }
            farm.amount = 400; // Max out farm amount (arbitrary high, change as desired)
            if (typeof farm.level !== "undefined") farm.level = 10; // Max level
            farm.minigameUnlocked = 1;
            if (!farm.minigame && typeof farm.loadMinigame === "function") farm.loadMinigame();
            setTimeout(function() {
                if (farm.minigame && farm.minigame.seeds) {
                    Object.keys(farm.minigame.seeds).forEach(s => Game.UnlockSeed(s));
                    // Unlock all upgrades in garden minigame
                    if (farm.minigame.upgrades) {
                        Object.keys(farm.minigame.upgrades).forEach(u => farm.minigame.upgrades[u].unlocked = 1);
                    }
                }
            }, 250);
            createAlertWindow('Maxed out Farms, unlocked all seeds and upgrades in Garden!', 'Max Farms & Garden');
        }

        // Danger Feature: Break Game (999... Cursors)
        function breakGameCursors() {
            if (!confirm('WARNING: This will attempt to set your Cursor amount to a number so large it will break or freeze your game/tab! Are you sure?')) return;
            try {
                Game.Objects['Cursor'].amount = BigInt("999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
            } catch (e) {
                Game.Objects['Cursor'].amount = Number.MAX_SAFE_INTEGER;
            }
            createAlertWindow("You broke the game. If your browser freezes, that's your fault!","BROKEN GAME");
        }

        // Basic Feature Functions
        function addCookies() {
            let val = parseFloat(document.getElementById('cc-add-cookies').value);
            if (!isNaN(val)) {
                Game.cookies += val;
                createAlertWindow(`Added ${val} cookies!`);
            } else {
                createAlertWindow("Please enter a valid number.");
            }
        }
        function addLumps() {
            let val = parseInt(document.getElementById('cc-add-lumps').value);
            if (!isNaN(val)) {
                Game.lumps = val;
                createAlertWindow(`Set lumps to ${val}.`);
            } else {
                createAlertWindow("Please enter a valid number.");
            }
        }
        function removeCookies() {
            Game.cookies = 0;
            createAlertWindow("Removed all cookies.");
        }
        function toggleAutoClicker() {
            if (!autoClickerOn) {
                autoClickerInterval = setInterval(()=>Game.ClickCookie(),10);
                document.getElementById('cc-auto-clicker-btn').innerText = "Stop Auto-Clicker";
                autoClickerOn = true;
            } else {
                clearInterval(autoClickerInterval);
                document.getElementById('cc-auto-clicker-btn').innerText = "Start Auto-Clicker";
                autoClickerOn = false;
            }
        }

        // UNLOCK ALL UPGRADES (skips debug/test upgrades and exclusion list)
        function unlockAllUpgrades() {
            const excludeNames = [
                "occult obstruction",
                "steamed cookies",
                "ultrascience",
                "gold hoard",
                "neuromancy",
                "perfect idling",
                "wrinkler doormat",
                "reindeer season",
                "eternal seasons",
                "magic shenanigans",
                "clucose-charged air",
                "turbo-charged soil",
                "a really good guide book"
            ];
            let count = 0;
            Object.values(Game.UpgradesById).forEach(upg => {
                // Skip any upgrade that is a debug/test upgrade or in the exclude list
                if (
                    excludeNames.includes(upg.name.toLowerCase()) ||
                    upg.debug ||
                    /debug|test/i.test(upg.name)
                ) {
                    return;
                }
                upg.unlock();
                if (upg.bought === 0) {
                    upg.bought = 1;
                    if (typeof upg.onBuy === 'function') upg.onBuy();
                }
                count++;
            });
            if (typeof Game.RecalculateGains === "function") Game.RecalculateGains();
            createAlertWindow(`Force-bought ${count} upgrades (no debug/test/upgrades in exclusion list)!`);
        }

        // UNLOCK ALL ACHIEVEMENTS (never gives "cheated cookies taste awful" even if id/name/desc changes)
        function unlockAllAchievements() {
            // Robustly skip "cheated cookies taste awful" using multiple checks
            let count = 0;
            Object.values(Game.AchievementsById).forEach(a => {
                // Check if id or name or description or base desc matches any possible "cheated cookies taste awful" signature
                const forbidden = [
                    "cheated cookies taste awful", // name (case-insensitive)
                    "cheated cookies taste awful.", // name (with extra .)
                    "cheated", // partial name
                    "cheater", // partial
                    "cheating", // partial
                    "taste awful", // partial
                    "Game.cookies=Infinity", // old description
                    "Cheat", // desc
                ];
                let skip = false;
                // Check id (as string)
                if (typeof a.id !== "undefined" && (a.id === 7 || a.id === "7")) skip = true;
                // Check name/desc (case-insensitive)
                if (typeof a.name === "string" && forbidden.some(bad => a.name.toLowerCase().includes(bad))) skip = true;
                if (typeof a.desc === "string" && forbidden.some(bad => a.desc.toLowerCase().includes(bad))) skip = true;
                if (typeof a.baseDesc === "string" && forbidden.some(bad => a.baseDesc.toLowerCase().includes(bad))) skip = true;
                // Defensive: skip if won already
                if (a.won) skip = true;
                if (!skip) {
                    Game.Win(a.name);
                    count++;
                }
            });
            createAlertWindow(`Unlocked ${count} achievements (never the "cheated cookies taste awful" achievement)!`);
        }

        const fpsInput = document.getElementById('cc-fps-input');
        const setFpsBtn = document.getElementById('cc-set-fps-btn');
        const fpsValue = document.getElementById('cc-fps-value');
        function setFPS(val) {
            val = parseInt(val);
            if (!isNaN(val) && val > 0 && val <= 999999) {
                Game.fps = val;
                fpsValue.innerText = val;
            } else {
                createAlertWindow("Enter a positive FPS value up to 999999.");
            }
        }
        setFpsBtn.onclick = function() {
            setFPS(fpsInput.value);
        };
        fpsInput.onkeydown = function(e) {
            if (e.key === 'Enter') setFPS(fpsInput.value);
        };
        setInterval(()=>{fpsValue.innerText = Game.fps;}, 2000);

        function ruinTheFun() {
            if (confirm("Are you sure you want to ruin your fun? If you do this there is no going back.")) {
                Game.cookies = 1e+100;
                Object.values(Game.UpgradesById).forEach(upg => upg.unlock());
                Object.values(Game.AchievementsById).forEach(a => {
                    if (!a.won) a.unlock();
                });
                Object.values(Game.ObjectsById).forEach(obj => obj.amount = 1000);
                Game.lumps = 9999;
                if (Game.gardenSeedCatalog) {
                    Object.keys(Game.gardenSeedCatalog).forEach(s=>Game.UnlockSeed(s));
                }
                createAlertWindow("The fun has been ruined! Game fully completed.");
            }
        }

        // Event listeners
        document.getElementById('cc-set-product-level-btn').onclick = setProductLevelBtn.onclick;
        document.getElementById('cc-product-level-input').onkeydown = productLevelInput.onkeydown;
        document.getElementById('cc-set-building-amount-btn').onclick = setBuildingAmountBtn.onclick;
        document.getElementById('cc-building-amount-input').onkeydown = buildingAmountInput.onkeydown;
        document.getElementById('cc-bigcookie-spin-btn').onclick = bigCookieSpin;
        document.getElementById('cc-golden-parade-btn').onclick = goldenCookieParade;
        document.getElementById('cc-doge-mode-btn').onclick = dogeMode;
        document.getElementById('cc-nyancat-btn').onclick = nyanCatMode;
        document.getElementById('cc-add-cookies-btn').onclick = addCookies;
        document.getElementById('cc-add-lumps-btn').onclick = addLumps;
        document.getElementById('cc-remove-cookies-btn').onclick = removeCookies;
        document.getElementById('cc-auto-clicker-btn').onclick = toggleAutoClicker;
        document.getElementById('cc-unlock-upgrades-btn').onclick = unlockAllUpgrades;
        document.getElementById('cc-unlock-achievements-btn').onclick = unlockAllAchievements;
        document.getElementById('cc-max-farms-garden-btn').onclick = maxOutFarmsGarden;
        document.getElementById('cc-custom-notification-btn').onclick = customNotificationPopup;
        document.getElementById('cc-ruin-btn').onclick = ruinTheFun;
        document.getElementById('cc-break-game-btn').onclick = breakGameCursors;
        document.getElementById('cc-close-btn').onclick = () => menu.remove();

        // Console info
        console.log('Jayden\'s Mod Menu loaded. Drag the top bar to move. Press "/" to toggle menu visibility.');
    }
})();